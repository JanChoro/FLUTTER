//importamos
import 'dart:ffi';

import 'package:sqflite/sqflite.dart';
import 'db_helper.dart';

//Clase
class Producto {
  //Variables
  final int? id;
  final String nombre;
  final Float precio;
  final int cantidad;
  final int estado;

  //Constructor
  Producto(
      {this.id,
      required this.nombre,
      required this.precio,
      required this.cantidad,
      required this.estado});

  //Mapeamos
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nombre': nombre,
      'precio': precio,
      'cantidad': cantidad,
      'estado': estado
    };
  }

  //ToString()
  @override
  String toString() {
    return '{Id:$id\nNombre:$nombre\nPrecio:$precio\nCantidad:$cantidad\nEstado:$estado}';
  }

  //-----------CRUD-----------

  //Listar
  static Future<List<Producto>> listaP() async{
    // traemos la Base de Datos
  final Database db = await DbHelper.initDb();
    //Generamos la lista
final List<Map<String, dynamic>> maps = await db.query('Productos');
// Retornamos lo que vamos a mostrar
    return List.generate(maps.length, (i){
      return Producto(id:maps[i]['id'] ,nombre: maps[i]['nombre'], precio: maps [i]['precio'], cantidad: maps[i]['cantidad'], estado: maps[i]['estado']);
    });
  }

  //Crear

  //Actualizar

  //Eliminar
}
