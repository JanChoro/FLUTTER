//Importamos: sqlite y dbHelper
import 'package:sqflite/sqflite.dart';
import 'db_helper.dart';

class Cliente {
  //Variables
  final int? id;
  final String name;
  final String apellido;
  final String correo;
  final int telefono;
  final String direccion;
  final int estado;

  //Constructor
  const Cliente(
      {this.id,
      required this.name,
      required this.apellido,
      required this.correo,
      required this.telefono,
      required this.direccion,
      required this.estado});

  //Mapeamos los datos
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'apellido': apellido,
      'correo': correo,
      'telefono': telefono,
      'direccion': direccion,
      'estado': estado
    };
  }

  //ToString()
  @override
  String toString() {
    // TODO: implement toString
    return 'Cliente{Id: $id\n Nombre:$name\nApellido:$apellido\nCorreo:$correo\nTeléfono:$telefono\nDirección:$direccion\nEstado:$estado}';
  }

  // ---------CRUD---------

  //Listar
  static Future<List<Cliente>> listarC() async {
    final Database db = await DbHelper.initDb();
    final List<Map<String, dynamic>> maps = await db.query('Clientes');
    return List.generate(maps.length, (i) {
      return Cliente(
          id: maps[i]['id'],
          name: maps[i]['name'],
          apellido: maps[i]['apellido'],
          correo: maps[i]['correo'],
          telefono: maps[i]['telefono'],
          direccion: maps[i]['direccion'],
          estado: maps[i]['estado']);
    });
  }

  //Crear
  static Future crearC(Cliente cliente) async {
    final Database db = await DbHelper.initDb();
    final int result = await db.insert('Cliente', cliente.toMap());
    return result;
  }

  //Actualizar
  static Future<int> actualizarC(Cliente cliente) async {
    final Database db = await DbHelper.initDb();
    return await db.update(
      'Clientes',
      cliente.toMap(),
      where: 'id = ?',
      whereArgs: [cliente.id],
    );
  }
  //Eliminar
  static Future<int> eliminarC(int id) async{
    final Database db = await DbHelper.initDb();
    return await db.delete(
      'Clientes',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
